from .maltiverse import Maltiverse
__all__ = ['Maltiverse']
